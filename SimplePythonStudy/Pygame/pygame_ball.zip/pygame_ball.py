import pygame, os 
import sys

dir = os.path.dirname(__file__)
#建立遊戲視窗
pygame.init()  # 初始化pygame
size = width, height = 600, 400  # 設定視窗大小
screen = pygame.display.set_mode(size)  # 顯示視窗
color = (255, 255, 255)  # 設定顏色 底色白色

ball = pygame.image.load(os.path.join(dir,'ball.png'))  # 載入圖片
ballrect = ball.get_rect()  # 獲取矩形區域

speed = [5, 5]  # 設定移動的X軸、Y軸
clock = pygame.time.Clock()  # 設定時鐘

while True:  # 死迴圈確保視窗一直顯示
    screen.fill(color)  # 填充顏色
    screen.blit(ball, ballrect)  # 將圖片畫到視窗上
    ballrect = ballrect.move(speed)  # 移動小球
    clock.tick(60)  # 每秒執行60次

    # 碰到左右邊緣, x軸改為負數
    if ballrect.left < 0 or ballrect.right > width:
        speed[0] = -speed[0]
    # 碰到上下邊緣, y軸改為負數
    if ballrect.top < 0 or ballrect.bottom > height:
        speed[1] = -speed[1]
        
    pygame.display.flip()  # 更新全部顯示
    
    #關閉程式
    for event in pygame.event.get():  # 遍歷所有事件
        if event.type == pygame.QUIT:  # 如果單擊關閉視窗，則退出
            sys.exit()  

pygame.quit()  # 退出pygame