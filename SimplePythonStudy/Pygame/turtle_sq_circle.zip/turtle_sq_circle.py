import turtle, time 
# 將畫筆定位到原點
turtle.goto(0,0)
# 控制畫筆的速度
turtle.speed(3)
turtle.color('red')
turtle.pensize(4)

# 從原點開始，畫出一個邊長為100的正方形
for i in range(4):
    # 正向運動 100 的距離
    turtle.forward(100)
    # 向右偏 90 度
    turtle.right(90)

# 將畫筆定位到原點, 向右移動
turtle.home()
turtle.penup()
turtle.forward(200)
turtle.pendown()

# 畫出一個半徑為100的圓
turtle.circle(50,360)

time.sleep(3)


