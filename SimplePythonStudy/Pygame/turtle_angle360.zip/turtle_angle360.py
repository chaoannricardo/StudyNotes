import turtle
turtle.speed(100)

for i in range(360):
    turtle.setheading(i)      #畫筆的方向
    for i in range(100):
        for i in range(50):    
            turtle.forward(i)
            turtle.right(50)

time.sleep(3)