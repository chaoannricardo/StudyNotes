import turtle, time 
turtle.setup(500,500)
turtle.speed(100)

for i in range(360):
    turtle.setheading(i)      #畫筆的方向
    for i in range(4):
        turtle.forward(150)
        turtle.left(90)

time.sleep(3)