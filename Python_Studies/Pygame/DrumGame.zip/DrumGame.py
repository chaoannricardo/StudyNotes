import pygame, os
pygame.init()
dir = os.path.dirname(__file__)
#pygame.mixer.pre_init(44100, 16, 2, 4096)  #frequency, size, channels, buffersize

#建立遊戲視窗
windowSize = [400, 300]
screen = pygame.display.set_mode(windowSize)
pygame.display.set_caption('Drum Machine')

#音效們
HH = pygame.mixer.Sound(os.path.join(dir,'HH.wav'))
crash = pygame.mixer.Sound(os.path.join(dir,'crash.wav'))
snare = pygame.mixer.Sound(os.path.join(dir,'snare.wav'))
kick = pygame.mixer.Sound(os.path.join(dir,'kick.wav'))

done = False
while not done:
    #按鈕們   #Rect(color,[left, top, width, height)
    pygame.draw.rect(screen, (0, 255, 50), [75, 50, 50, 100])           
    pygame.draw.rect(screen, (255, 40, 50), [135, 50, 50, 100])
    pygame.draw.rect(screen, (255, 0, 255), [195, 50, 50, 100])
    pygame.draw.rect(screen, (255, 100, 0), [255, 50, 50, 100])
    pygame.display.flip()
    
    #按鍵按下
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:
        pygame.mixer.Channel(0).play(HH)
        pygame.draw.rect(screen, (100, 255, 255), [75, 50, 50, 100])
        pygame.display.flip()  
    if keys[pygame.K_s]:
        pygame.mixer.Channel(1).play(crash)
        pygame.draw.rect(screen, (100, 255, 255), [135, 50, 50, 100])
        pygame.display.flip()
    if keys[pygame.K_d]:
        pygame.mixer.Channel(2).play(kick)
        pygame.draw.rect(screen, (100, 255, 255), [195, 50, 50, 100])
        pygame.display.flip()
    if keys[pygame.K_f]:
        pygame.mixer.Channel(3).play(snare)
        pygame.draw.rect(screen, (100, 255, 255), [255, 50, 50, 100])
        pygame.display.flip()
    
    # 關閉程式
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

pygame.quit()
