public class IOTest {
    public static void main(String[] args) {
        //http://iosnetworkdemo.appspot.com/json.jsp?msg=helloWorld
        //此將此網址回傳的結果示在Console中
        

    }
}
