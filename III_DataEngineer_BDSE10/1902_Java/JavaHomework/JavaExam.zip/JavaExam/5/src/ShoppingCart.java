import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    public static void main(String[] args) {

        //實作1.加入二台Notebook("Asus",30000),Notebook("Acer",20000),Food("Cookie",200)到shoppingList中
        List<Product> shoppingList = new ArrayList<Product>();
        
        
        //實作2.利用for迴圈，計算shoppingList中的總金額,並印在Console中
        for (Product product : shoppingList) {

        }

        //實作3.利用for迴圈，計算shoppingList中是Notebook型態的總金額,並印在Console中



    }
}
