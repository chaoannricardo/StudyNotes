public class Employee {
    public int empno;
    public String name;
    public long salary;
}
