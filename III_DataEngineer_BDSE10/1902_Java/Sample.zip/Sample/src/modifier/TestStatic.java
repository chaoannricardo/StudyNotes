package modifier;

public class TestStatic {
    public static void main(String[] args) {

        System.out.println(Calculator.tax);
    }
}
