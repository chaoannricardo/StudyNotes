public class HelloWorld {

    public static void main(String[] args) {
        //step1
        System.out.println("Hello World");
        //step2， 讀取參數列狀態
        //System.out.println("Hello World!=" + args[0]);
        //System.out.println("Hello World!=" + args[1]);
        //System.out.println("Hello World!=" + args[2]);

    }
}
