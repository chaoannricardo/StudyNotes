package interFace;

public interface SayHello {
    String sayHi();
}
