package interFace;

public interface Lawyer {
    void sue();
}
