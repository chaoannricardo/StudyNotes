package interFace;

import java.util.Date;

public interface Expirable {

    Date 最後使用期限();

}
