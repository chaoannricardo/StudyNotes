package interFace;

public class People {
}
