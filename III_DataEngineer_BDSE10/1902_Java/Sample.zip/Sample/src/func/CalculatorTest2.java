package func;

/**
 * Created by vincent on 2017/6/29.
 */
public class CalculatorTest2 {
    
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        int sum = calculator.add(1,2);
        System.out.println(sum);
    }

    
}
