public class TestAssertion {
    public static void main(String[] args) {

        int speed = 1000;

        assert (speed < 1000) : "超人開蝙蝠車嗎，不太對哦";


    }
}
