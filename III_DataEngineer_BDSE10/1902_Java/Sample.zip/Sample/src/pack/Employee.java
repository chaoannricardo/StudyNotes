package pack;

public class Employee {

    public String name;

    public static void main(String[] args) {
        System.out.println("Employee 在pack 套件中");
    }

}
