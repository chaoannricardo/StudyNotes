package generic;

public class NoteInt {
    private Integer content;

    public NoteInt(Integer content) {
        this.content = content;
    }

    public Integer getContent() {
        return content;
    }

    public void setContent(Integer content) {
        this.content = content;
    }
}
