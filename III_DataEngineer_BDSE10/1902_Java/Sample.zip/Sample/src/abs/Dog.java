package abs;

public class Dog extends Animal {
    @Override
    public String sound() {
        return "??";
    }
}
