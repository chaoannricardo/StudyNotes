package abs;

public class Cat extends Animal {

    @Override
    public String sound() {
        return "meow";
    }
}
