
public class TestPackage {
    
    public static void main(String[] args) {


        pack.Employee employee = new pack.Employee();
        employee.name = "James";

        System.out.println("Hello World "+employee.name);

        

    }
}
