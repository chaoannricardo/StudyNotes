CREATE PROCEDURE QueryEmployee 
AS
BEGIN
   SELECT * from emp 
END